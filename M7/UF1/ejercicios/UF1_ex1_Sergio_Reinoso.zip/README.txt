Adjunto ficheros de:
- Manual avanzado
- Manual de usuario
- Interfaz glade

NO adjunto:
- Fichero de python(no he acabado de hacer que funcione)
- Ficheros *.rst
- Ficheros *.plantuml
- Ficheros *.png

En caso de necesitar cualquiera de dichos ficheros, por favor, mandame un mail a sreinoso@iesjoandaustria.org.

P.D.: Siento el retraso, pero como ya te comenté, tenía unos timings de un proyecto un poco puñeteros.
